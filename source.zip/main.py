import os
import logging
from typing import List, Optional, Dict, Any
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from google.cloud import aiplatform
import vertexai
from vertexai.generative_models import GenerativeModel, ChatSession, Content, Part

# --- CONFIGURACIÓN ---
PROJECT_ID = "semhys-chat"  # Tu ID real
LOCATION = "us-central1"    # Tu ubicación real
MODEL_NAME = "gemini-1.5-pro-001" # Modelo SOTA estable (o gemini-1.5-flash)

# Configuración de Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("semhys-backend")

# Inicializar Vertex AI
try:
    vertexai.init(project=PROJECT_ID, location=LOCATION)
    logger.info(f"Vertex AI inicializado en {PROJECT_ID}")
except Exception as e:
    logger.error(f"Error inicializando Vertex AI: {e}")

app = FastAPI(title="Semhys Chat API", version="1.0.0")

# CORS para permitir peticiones desde tu web (o localhost)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # En producción, restringir a https://semhys.com
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- MODELOS DE DATOS ---
class ChatMessage(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    message: str
    history: List[ChatMessage] = []
    language: str = "es"

class ChatResponse(BaseModel):
    response: str
    metadata: Optional[Dict[str, Any]] = None

# --- LÓGICA DE GROUNDING (Búsqueda de Datos) ---
# Aquí conectaremos el Data Store ID más adelante.
DATA_STORE_ID = "semhys-data-2025-datastore" # Placeholder: Reemplazar con ID real si se encuentra

# --- ENDPOINTS ---
@app.get("/")
async def root():
    return {"status": "ok", "service": "Semhys AI Backend", "model": MODEL_NAME}

@app.post("/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    try:
        logger.info(f"Recibido mensaje: {request.message} (Lang: {request.language})")
        
        # 1. Configurar el Modelo Gemini
        model = GenerativeModel(MODEL_NAME)
        
        # 2. Construir el historial compatible con Gemini
        # Gemini usa roles 'user' y 'model'. Mapeamos 'assistant' -> 'model'.
        chat_history = []
        for msg in request.history:
            role = "user" if msg.role == "user" else "model"
            chat_history.append(Content(role=role, parts=[Part.from_text(msg.content)]))

        # 3. Iniciar sesión de chat
        chat: ChatSession = model.start_chat(history=chat_history)
        
        # 4. Prompt de Sistema (Contexto de Ingeniería)
        # Inyectamos personalidad y contexto antes de la respuesta
        system_instruction = (
            f"Eres el Ingeniero Senior de Semhys. Tu especialidad es hidráulica, tratamiento de aguas y eficiencia energética. "
            f"Responde en {request.language}. Sé técnico, preciso, y profesional. "
            f"Si no sabes algo, no lo inventes. Usa formato Markdown para listas y negritas."
        )
        
        # 5. Enviar mensaje
        # Nota: En Gemini Python SDK, system instruction se pasa al modelo o se añade al prompt.
        # Aquí lo concatenamos sutilmente al último mensaje para forzar el comportamiento, 
        # o usamos la API de system_instruction si el modelo lo soporta nativamente en init (Gemini 1.5 lo soporta).
        
        # Re-instanciamos con system instruction para asegurar cumplimiento
        model_with_sys = GenerativeModel(
            MODEL_NAME,
            system_instruction=[system_instruction]
        )
        chat_with_sys = model_with_sys.start_chat(history=chat_history)
        
        response = chat_with_sys.send_message(request.message)
        
        # 6. Procesar respuesta
        response_text = response.text
        
        return ChatResponse(
            response=response_text,
            metadata={"model": MODEL_NAME, "tokens": response.usage_metadata.total_token_count}
        )

    except Exception as e:
        logger.error(f"Error procesando chat: {e}")
        # Fallback elegante
        return ChatResponse(response=f"Lo siento, hubo un error técnico conectando con mi cerebro en la nube. Detalles: {str(e)}")

# Para correr localmente: uvicorn main:app --reload
